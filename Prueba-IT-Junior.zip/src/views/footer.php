</div> <!-- Cerrar el contenedor principal -->
<script src="assets/js/scripts.js"></script>
</body>
</html>
