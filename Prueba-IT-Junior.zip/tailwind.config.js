module.exports = {
  content: ["./public/**/*.php", "./src/**/*.php"],
  theme: {
    extend: {},
  },
  plugins: [],
};
