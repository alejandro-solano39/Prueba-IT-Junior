<?php
// Configuración de conexión a la base de datos
$host = 'localhost';
$dbname = 'Prueba_IT_Junior';
$username = 'root';
$password = '';

try {
    // Crear conexión a la base de datos usando PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    // Configurar el modo de error de PDO para lanzar excepciones
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Manejar error de conexión
    die("Error de conexión: " . $e->getMessage());
}
