<?php
session_start();
header("Content-Type: application/json"); // Asegura respuesta en JSON

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'No autenticado']);
    http_response_code(401);
    exit;
}

require_once './config.php'; // Conexión a la base de datos
require_once '../src/models/User.php'; // Archivo del modelo de usuario

$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'read':
            // Obtener usuarios
            $stmt = $pdo->query("SELECT id, nombre, email FROM users");
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['data' => $users]);
            break;

        case 'create':
            // Leer y decodificar el cuerpo JSON de la solicitud
            $data = json_decode(file_get_contents("php://input"), true);

            if (!isset($data['nombre'], $data['email'], $data['password'])) {
                throw new Exception("Datos incompletos para crear el usuario");
            }

            // Preparar la inserción en la base de datos
            $stmt = $pdo->prepare("INSERT INTO users (nombre, email, password) VALUES (?, ?, ?)");
            $stmt->execute([
                $data['nombre'],
                $data['email'],
                password_hash($data['password'], PASSWORD_DEFAULT)
            ]);

            echo json_encode(['message' => 'Usuario creado correctamente']);
            http_response_code(201); // Código de respuesta HTTP 201 (Creado)
            break;

        case 'getUser':
            // Validar que el ID del usuario se haya proporcionado
            if (!isset($_GET['id'])) {
                throw new Exception("ID de usuario no proporcionado");
            }

            $userId = (int) $_GET['id'];

            // Consultar los datos del usuario en la base de datos
            $stmt = $pdo->prepare("SELECT id, nombre, email FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                echo json_encode(['data' => $user]);
            } else {
                throw new Exception("Usuario no encontrado");
            }
            break;

        case 'update':
            // Decodificar los datos de la solicitud JSON
            $data = json_decode(file_get_contents("php://input"), true);

            if (!isset($data['id'], $data['nombre'], $data['email'])) {
                throw new Exception("Datos incompletos para actualizar el usuario");
            }

            $stmt = $pdo->prepare("UPDATE users SET nombre = ?, email = ? WHERE id = ?");
            $stmt->execute([
                $data['nombre'],
                $data['email'],
                $data['id']
            ]);

            echo json_encode(['message' => 'Usuario actualizado']);
            break;

        case 'delete':
            // Decodificar los datos de la solicitud JSON
            $data = json_decode(file_get_contents("php://input"), true);

            if (!isset($data['id'])) {
                throw new Exception("ID no especificado para eliminación");
            }

            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$data['id']]);
            echo json_encode(['message' => 'Usuario eliminado']);
            break;

        default:
            throw new Exception("Acción no válida");
    }
} catch (Exception $e) {
    // Manejo de errores
    echo json_encode(['error' => $e->getMessage()]);
    http_response_code(500);
}
