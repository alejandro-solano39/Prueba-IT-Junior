# Gestión de Usuarios

Esta es una aplicación web para la administración de usuarios, que permite realizar operaciones CRUD (Crear, Leer, Actualizar y Eliminar) mediante una interfaz amigable y responsive. La aplicación utiliza tecnologías como PHP, MySQL, JavaScript (jQuery), Tailwind CSS, y SweetAlert2 para mejorar la experiencia del usuario.

## Tabla de Contenidos
- [Requisitos Previos](#requisitos-previos)
- [Instalación](#instalación)
- [Configuración](#configuración)
- [Ejecución](#ejecución)
- [Estructura del Proyecto](#estructura-del-proyecto)
- [Uso](#uso)
- [Tecnologías Usadas](#tecnologías-usadas)

## Requisitos Previos

1. **Servidor Web**: Se recomienda usar [XAMPP](https://www.apachefriends.org/) o [WAMP](https://www.wampserver.com/) para ejecutar un servidor Apache local con PHP y MySQL.
2. **PHP**: Versión 7.4 o superior.
3. **MySQL**: Base de datos MySQL para almacenar la información de usuarios.
4. **Composer** (opcional): Para instalar dependencias de PHP si se expanden las funcionalidades en el futuro.

## Instalación

### Paso 1: Clonar el Repositorio

Clona el repositorio en tu máquina local o descarga el código fuente.

git clone https://github.com/tu-usuario/nombre-repositorio.git
cd nombre-repositorio

## Paso 2: Configurar la Base de Datos
Abre el gestor de bases de datos de MySQL (phpMyAdmin en XAMPP o el cliente que prefieras).
Crea una nueva base de datos, por ejemplo, llamada gestion_usuarios.
Importa el archivo SQL para crear la tabla necesaria. Puedes hacer esto ejecutando el siguiente SQL:

CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL
);

## Paso 3: Configurar la Conexión a la Base de Datos
Abre el archivo config.php en el directorio raíz de tu proyecto.
Asegúrate de que los parámetros de conexión a la base de datos sean correctos. Actualiza los valores de DB_HOST, DB_NAME, DB_USER, y DB_PASSWORD según tu configuración local.

// config.php
define('DB_HOST', 'localhost');
define('DB_NAME', 'prueba_it_junior'); // Nombre de la base de datos
define('DB_USER', 'root');             // Usuario de MySQL
define('DB_PASSWORD', '');             // Contraseña de MySQL

## Paso 4: Configurar el Servidor Web
Si estás usando XAMPP, coloca la carpeta del proyecto en el directorio htdocs. Si es WAMP, colócala en www.
Accede a la aplicación en tu navegador: http://localhost/nombre-repositorio/public/.

## Ejecución
Inicia Apache y MySQL en XAMPP o WAMP.
Abre el navegador y visita http://localhost/nombre-repositorio/public/ para ver la aplicación en funcionamiento.
Estructura del Proyecto
prueba_it_junior/
│
├── public/                   # Carpeta pública accesible desde el navegador
│   ├── index.php             # Página principal
│   ├── assets/               # Archivos de estilos y JavaScript
│   │   ├── css/
│   │   │   └── styles.css    # Archivo CSS generado por Tailwind
│   │   └── js/
│   │       └── scripts.js    # Archivo JavaScript principal
│   ├── api.php               # API para manejar las solicitudes CRUD
│   └── config.php            # Configuración de la base de datos
│
├── src/                      # Código fuente y lógica de la aplicación
│   ├── controllers/          # Controladores PHP
│   │   └── UserController.php
│   ├── models/               # Modelos PHP
│   │   └── User.php
│   ├─ views/                # Vistas HTML de la aplicación
│     ├── header.php        # Encabezado común
│     ├── footer.php        # Pie de página común
│     ├── user-list.php     # Listado de usuarios
│     └── user-modal.php    # Modal para crear/editar usuarios
│   
└── README.md                 # Documentación del proyecto

## Uso
Agregar Usuario: Haz clic en el botón "Agregar Usuario" para abrir el modal de creación de usuario, completa los campos y guarda el nuevo usuario.
Editar Usuario: En la tabla de usuarios, haz clic en "Editar" para modificar los detalles del usuario seleccionado.
Eliminar Usuario: En la tabla de usuarios, haz clic en "Eliminar" para borrar un usuario. Aparecerá un mensaje de confirmación.
Cerrar Sesión: Haz clic en el botón de "Cerrar Sesión" en la parte superior para salir de la sesión.
Tecnologías Usadas
HTML: Estructura de la interfaz de usuario.
CSS y Tailwind CSS: Estilos y diseño responsivo.
JavaScript y jQuery: Interactividad y validación en el cliente.
SweetAlert2: Alertas visuales de éxito, error y confirmación.
PHP: Lógica de servidor y procesamiento de solicitudes.
MySQL: Almacenamiento de datos en base de datos relacional.
Font Awesome: Iconos para botones y elementos visuales.
Notas
Asegúrate de tener activadas las extensiones PDO y MySQL en tu configuración de PHP (php.ini).
Esta aplicación utiliza sesiones para la autenticación básica. Para entornos de producción, considera implementar métodos de autenticación más seguros.